# RighteousHack startup splash: "Narrow Way" (handoff for Grok Build)

Approved by Jon: the Narrow Way artwork, exactly as rendered in `original/05_narrow_way.png`,
becomes the startup splash. The only change: the star(s) above the mountains sparkle.
Everything else is static. This package is art and spec only; it contains no game code.

## Source of truth
- `original/05_narrow_way.ans`: final colored ASCII (ANSI 16 colors, black background). THE authoritative art.
- `data/artwork_cells.json`: same grid as portable data. 112 columns x 48 rows. `rows[r][c]` = glyph,
  `fg_rows[r][c]` = palette index (hex digit). Every row is exactly 112 chars; spaces are significant.
  Background is black (index 0) for every cell. Palette maps index -> SGR code -> RGB hex.
- `original/05_narrow_way.txt`: plain ASCII (trailing spaces trimmed, so use the JSON or .ans for layout).
- Colors used: 3 brown (#aa5500, SGR 33), 7 light gray (#aaaaaa, 37), 8 dark gray (#555555, 90),
  11 bright yellow (#ffff55, 93), 15 bright white (#ffffff, 97). Title "RIGHTEOUSHACK" is rows 2-6
  (yellow top 3 rows, brown bottom 2 rows).
- Verified: parsing the .ans and the JSON and re-rendering with the original renderer metrics
  (DejaVu Sans Mono 20px, 12x25 px cells, 32 px margin) is pixel-identical to the approved PNG.
  Run `python3 tools/parse_and_verify.py` (needs Pillow; font included in `source/`).

## Stars (only these cells may change)
See `data/star_positions.json` and `preview/star_selection_overlay.png` (magenta box).
The final art contains exactly ONE `+` glyph: column 44, row 11 (0-based), light gray (index 7).
Two gray `.` cells (95,9 and 22,10; cyan boxes) are listed as NOT approved candidates. Do not animate
them unless Jon confirms. If Jon wants several sparkling pluses, that is an art change needing his approval.

## Animation guidance (recommendations, not approved requirements)
- Keep the glyph `+` and its cell; vary only brightness within its hue (e.g. dark gray -> light gray -> white -> light gray).
- Tick around 100-200 ms; one sparkle cycle about 1-3 s with irregular/staggered timing. If more stars are later approved,
  stagger them so they never blink in sync. No strobing.
- Always return to the original baseline color (light gray, index 7).
- Update only star cells per tick. Never redraw or clear the full screen per frame (avoids flicker).
- See `preview/illustrative_star_twinkle.gif` (illustration only).

## Copy-paste prompt for Grok Build
```
Read README_GROK_BUILD.md and the files in this package. In C:\CODE\RighteousHack, add the approved
"Narrow Way" startup splash.

1. First inspect the existing startup, title and display flow and which window ports/terminals are
   actually built and supported (for example tty and Windows console). Report what you found before
   changing code. Do not assume function names or insertion points; find them in the repo.
2. Display the art as literal colored ASCII from data/artwork_cells.json or original/05_narrow_way.ans,
   not as a PNG image. Glyphs, positions and colors must match exactly (112x48, black background,
   the palette in the JSON). Do not redesign, recolor, crop, rescale or add text.
3. Animate only the cells listed under "stars" in data/star_positions.json (currently one '+' at
   col 44, row 11). Twinkle by brightness of its original gray hue, return to baseline, update only
   that cell, no full-screen redraw per frame. Do not animate the candidates list.
4. Show it once at startup. Recommend: any key continues/skips immediately, without delay. If the
   terminal is smaller than 112x48 or lacks color, do not crop silently; propose a sensible fallback
   (for example skip the splash or show plain text) and tell me what you chose.
5. The splash must not consume game turns, touch RNG state, leave timers running, or affect
   save/load/restore or the existing title/options flow. Restore the screen cleanly afterward.
6. Player-visible text must be plain ASCII; add no new prose I have not approved; no em dashes.
7. Tests: static cells and palette identical to artwork_cells.json; across animation frames only star
   cells differ; key skip is responsive; screen restored; behavior at small terminal sizes; starting a
   new game and restoring a save still work. Build and test, then report what passed and what is untested.
8. Do not push, merge or force-push anything without asking me.
```

## Files
See MANIFEST.json for SHA256 of every file. `source/render_collection.py` is the original renderer
(it rebuilds all 14 concepts and reads v2 inputs; `source/v2_input_narrow_way.ans` is the Narrow Way input
it needs). It is provenance only: the final .ans/JSON are what to implement.
