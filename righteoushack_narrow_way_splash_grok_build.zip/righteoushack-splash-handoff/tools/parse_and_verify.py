"""Parse 05_narrow_way.ans into a cell grid, write JSON, and re-render with the
original renderer metrics to verify pixel identity against the approved PNG."""
import json,re,sys,hashlib
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont,ImageChops
R=Path(__file__).resolve().parent.parent
W,H=112,48
PAL={0:'#000000',1:'#aa0000',2:'#00aa00',3:'#aa5500',4:'#0000aa',5:'#aa00aa',6:'#00aaaa',7:'#aaaaaa',8:'#555555',9:'#ff5555',10:'#55ff55',11:'#ffff55',12:'#5555ff',13:'#ff55ff',14:'#55ffff',15:'#ffffff'}
def parse(path):
    s=Path(path).read_text(); g=[[(' ',0) for _ in range(W)] for _ in range(H)]
    x=y=0; c=7; rows_len=[]
    for t in re.split('(\x1b\\[[0-9;]*[A-Za-z])',s):
        if t.startswith('\x1b'):
            if t.endswith('m'):
                for n in t[2:-1].split(';'):
                    n=int(n or 0)
                    if 30<=n<=37:c=n-30
                    elif 90<=n<=97:c=n-90+8
                    elif n==0:c=7
        else:
            for ch in t:
                if ch=='\n': rows_len.append(x); x=0; y+=1
                else:
                    assert x<W and y<H, (x,y); g[y][x]=(ch,c); x+=1
    assert all(l==W for l in rows_len) and len(rows_len)==H, (len(rows_len),set(rows_len))
    return g
def render(g,font_path):
    font=ImageFont.truetype(font_path,20); cw,chh=12,25
    im=Image.new('RGB',(W*cw+64,H*chh+64),'black'); d=ImageDraw.Draw(im)
    for y,row in enumerate(g):
        for x,(v,c) in enumerate(row):
            if v!=' ': d.text((32+x*cw,32+y*chh),v,font=font,fill=PAL[c])
    return im
if __name__=='__main__':
    font=sys.argv[1] if len(sys.argv)>1 else '/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf'
    g=parse(R/'original/05_narrow_way.ans')
    txt='\n'.join(''.join(ch for ch,c in r).rstrip() for r in g)+'\n'
    print('txt matches original .txt:', txt==(R/'original/05_narrow_way.txt').read_text())
    im=render(g,font); ref=Image.open(R/'original/05_narrow_way.png').convert('RGB')
    print('png size',ref.size,'pixel identical:', im.size==ref.size and ImageChops.difference(im,ref).getbbox() is None)
    d=json.loads((R/'data/artwork_cells.json').read_text())
    gj=[[(ch,int(f,16)) for ch,f in zip(r,fr)] for r,fr in zip(d['rows'],d['fg_rows'])]
    print('artwork_cells.json == .ans grid:', gj==g)
    print('artwork_cells.json render pixel identical:', ImageChops.difference(render(gj,font),ref).getbbox() is None)
