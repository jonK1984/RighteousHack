from PIL import Image, ImageDraw, ImageFont
from pathlib import Path
import zipfile
OUT=Path(__file__).resolve().parent
W,H=112,48
PAL={0:'#000000',1:'#aa0000',2:'#00aa00',3:'#aa5500',4:'#0000aa',5:'#aa00aa',6:'#00aaaa',7:'#aaaaaa',8:'#555555',9:'#ff5555',10:'#55ff55',11:'#ffff55',12:'#5555ff',13:'#ff55ff',14:'#55ffff',15:'#ffffff'}
class Art:
 def __init__(self): self.g=[[(' ',0) for x in range(W)] for y in range(H)]
 def text(self,x,y,s,c):
  for i,ch in enumerate(s):
   if 0<=x+i<W and 0<=y<H and ch!=' ': self.g[y][x+i]=(ch,c)
 def block(self,x,y,s,c):
  for j,line in enumerate(s.strip('\n').split('\n')):self.text(x,y+j,line,c)
 def title(self): self.text((W-12)//2,1,'RIGHTEOUSHACK',11)
 def save(self,name):
  txt='\n'.join(''.join(ch for ch,c in row).rstrip() for row in self.g)+'\n'
  assert txt.isascii()
  (OUT/(name+'.txt')).write_text(txt)
  ansi='\x1b[40m\x1b[2J\x1b[H'
  for row in self.g:
   prev=None
   for ch,c in row:
    if c!=prev: ansi+=f'\x1b[{30+c if c<8 else 90+c-8}m';prev=c
    ansi+=ch
   ansi+='\x1b[0m\x1b[40m\n'
  ansi+='\x1b[0m'
  (OUT/(name+'.ans')).write_text(ansi)
  font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf',20)
  cw,ch=12,25
  im=Image.new('RGB',(W*cw+64,H*ch+64),'black');d=ImageDraw.Draw(im)
  for y,row in enumerate(self.g):
   for x,(v,c) in enumerate(row):
    if v!=' ':d.text((32+x*cw,32+y*ch),v,font=font,fill=PAL[c])
  im.save(OUT/(name+'.png'))

font5={'R':['#### ','#   #','#### ','# #  ','#  ##'],'I':['#####','  #  ','  #  ','  #  ','#####'],'G':[' ####','#    ','# ###','#   #',' ####'],'H':['#   #','#   #','#####','#   #','#   #'],'T':['#####','  #  ','  #  ','  #  ','  #  '],'E':['#####','#    ','#### ','#    ','#####'],'O':[' ### ','#   #','#   #','#   #',' ### '],'U':['#   #','#   #','#   #','#   #',' ### '],'S':[' ####','#    ',' ### ','    #','#### '],'A':[' ### ','#   #','#####','#   #','#   #'],'C':[' ####','#    ','#    ','#    ',' ####'],'K':['#   #','#  # ','###  ','#  # ','#   #']}
def title(a):
 for i,l in enumerate('RIGHTEOUSHACK'):
  for y,line in enumerate(font5[l]):a.text(20+i*6,2+y,line,11 if y<3 else 3)
def clear(a,x,y,w,h):
 for yy in range(y,y+h):
  for xx in range(x,x+w):
   if 0<=xx<W and 0<=yy<H:a.g[yy][xx]=(' ',0)
import re, shutil
NAMES=[]
def finish(a,n,name):
 stem=f'{n:02d}_{name}';a.save(stem);NAMES.append(stem)
def scene():
 a=Art();title(a);return a
def old(name):
 a=Art();s=(OUT/'sources'/(name+'.ans')).read_text();x=y=0;color=7
 for t in re.split('(\x1b\\[[0-9;]*[A-Za-z])',s):
  if t.startswith('\x1b'):
   if t.endswith('m'):
    for n in t[2:-1].split(';'):
     n=int(n or 0)
     if 30<=n<=37:color=n-30
     elif 90<=n<=97:color=n-90+8
  else:
   for ch in t:
    if ch=='\n':x=0;y+=1
    else:
     if x<W and y<H:a.g[y][x]=(ch,color)
     x+=1
 return a
# 1: large gray wordmark; the sword floats freely, no stone.
a=scene()
for row in a.g:
 for x,(ch,col) in enumerate(row):
  if ch!=' ':row[x]=(ch,15 if col==11 else 7)
a.block(49,11,r'''
     .---.
     | + |
     '---'
      |=|
      |=|
      |=|
      |=|
 .____|=|____.
<_____.+._____>
      |:|
      |:|
      |:|
      |:|
      |:|
      |:|
      |:|
      |:|
      |:|
      |:|
      |:|
      |:|
      |:|
      |:|
      |:|
      |:|
      \:/
       V
''',15)
for y in range(11,20):
 for x in range(49,66):
  ch,col=a.g[y][x]
  if ch!=' ':a.g[y][x]=(ch,11)
a.text(42,20,'+',15);a.text(68,27,'+',15)
a.text(37,41,'____________     ____________',8)
finish(a,1,'sword_beneath_title')
finish(old('shattered_gate'),2,'shattered_gate')
finish(old('armor_of_god'),3,'armor_of_god')
# 4: broad sweeping wings and a planted sword, conquered unmarked banner.
a=scene()
wing=r'''
                       _.-'
                   _.-' /'
               _.-'   /'
           _.-'     /'
        .-'       /'
      .'  /     /'
     /   /    /'
    /   /   /'
   /   /  /'
  /   / /'
 /   //'
/___/'
'''
# Deliberate feather fans flank a central armored angel.
a.block(15,10,wing,15)
tr=str.maketrans('/\\<>()','\\/><)(')
for j,l in enumerate(wing.strip('\n').splitlines()):a.text(112-15-len(l),10+j,l[::-1].translate(tr),15)
for i in range(6):
 a.text(17+i*3,21-i,'/___/',7);a.text(88-i*3,21-i,'\\___\\',7)
a.block(45,17,r'''
        ____
       /____\
       | -- |
        \__/
     ___/==\___
    /  /||||\  \
   /__/ |||| \__\
   | |  ||||  | |
   |_|  ||||  |_|
       /====\
      /||||||\
     /_||||||_\
       | || |
       | || |
       |_||_|
      /__||__\
''',15)
a.block(41,26,r'''
   |
 --+--
   |:|
   |:|
   |:|
   |:|
   |:|
   |:|
   |:|
   |:|
   |:|
___|:|___
''',11)
a.block(67,31,r'''
        /________
       /   /    /
      /___/    <
     /    \____/
    /
   /
__/_
''',1)
a.text(27,40,'______/___________/__________________\\________',8)
finish(a,4,'michael_victorious')
# 5: reconstruct mountains with clearly separate planes and controlled hatching.
a=old('narrow_way')
# erase old mountain region, retain road and traveler by selecting only gray rock.
for y in range(8,H):
 for x in range(W):
  ch,col=a.g[y][x]
  if col==8:a.g[y][x]=(' ',0)
a.block(1,11,r'''
                    /\
                   /| \
          /\      / |  \      /\
         /| \____/  |   \    /| \
    /\  / | /   /   |    \__/ |  \
   /| \/  |/   /    |   /  /  |   \
  / | /   /   /     |  /  /   |    \_
 /  |/   /   /      | /  /    |   /  \
/   /   /   /       |/  /     |  /    \
   /   /   /       /   /      | /      \
  /   /   /       /   /       |/        \
 /   /   /       /   /       /           \
/   /   /       /   /       /    /|       \
   /   /       /   /       /    / |        \
  /   /       /   /       /    /  |         \
 /   /       /   /       /    /   |          \
/   /       /   /       /    /    |           \
   /       /   /       /    /     |            \
  /       /   /       /    /      |
 /       /   /       /    /       |
/       /   /       /    /        |
       /   /       /    /         |
      /   /       /    /          |
     /   /       /    /           |
    /   /       /    /            |
   /   /       /    /             |
  /   /       /    /              |
 /   /       /    /               |
/   /       /    /                |
''',8)
# sun-facing crisp ridge; darker parallel slash patterns are geological planes.
a.block(1,11,r'''
                    /\
                   /  \
          /\      /    \      /\
         /  \____/      \    /  \
    /\  /               \__/    \
   /  \/                         \
  /                               \_
 /                                  \
/                                    \
''',7)
for x,y in [(5,21),(9,24),(4,28),(14,19),(18,22),(23,17),(27,20),(24,26),(10,31),(5,35),(18,33),(31,25),(37,29)]:
 a.text(x,y,'//',8)
a.block(87,13,r'''
            /\
           /| \
      /\  / |  \
     /| \/  |   \
    / | /   |    \
   /  |/   /|     \
  /   /   / |      \
 /   /   /  |       \
/   /   /   |        \
   /   /    |       /|
  /   /     |      / |
 /   /      |     /  |
/   /       |    /   |
   /        |   /    |
  /         |  /     |
 /          | /      |
/           |/       |
           /         |
          /          |
         /           |
''',8)
a.block(87,13,r'''
            /\
           /  \
      /\  /    \
     /  \/      \
    /            \
   /              \
  /                \
 /                  \
/                    \
''',7)
# Ensure mountains remain behind the exact golden trail and foreground traveler.
orig=old('narrow_way')
for y in range(8,H):
 for x in range(W):
  ch,col=orig.g[y][x]
  if ch!=' ' and col in (3,11,15):a.g[y][x]=(ch,col)
# Clear road interior from rock overlaps, preserving original traveler.
pts=[(75,80),(74,79),(73,78),(71,76),(69,74),(66,72),(62,69),(59,67),(58,67),(59,69),(61,72),(63,75),(64,77),(64,78),(62,78),(59,77),(55,75),(50,72),(45,68),(40,64),(36,60),(33,57),(31,56),(30,56),(29,56),(28,57),(27,58),(26,59),(25,60)]
for j,(l,r) in enumerate(pts):
 for x in range(l+1,r):a.g[j+16][x]=orig.g[j+16][x]
finish(a,5,'narrow_way')
shutil.copyfile(OUT/'05_narrow_way.png',OUT/'narrow_way.png')
# 6: rock-cut tomb, unmistakable open doorway and large rolled stone.
a=scene()
a.block(17,12,r'''
                       __..----------------..__
                 __.--'       /                 `--.__
             _.-'      ______/_______                 `-._
          .-'         /              \      ___           `.
        .'           /                \____/   \            \
       /            /       ________           \             \
      /     _______/     .-'        `-.         \             \
     /     /            /              \         \             \
    /     /            /                \         \             \
   /     /            |                  |         \             \
  /_____/             |                  |          \_____________\
  |                   |                  |                        |
  |      /            |                  |        /               |
  |     /             |                  |       /                |
  |____/              |                  |      /                 |
 /                    |__________________|_____/                  |
/____________________/____________________\_______________________\
''',8)
a.block(40,18,r'''
        .------------.
       / .----------. \
      / /            \ \
     | |              | |
     | |              | |
     | |              | |
     | |              | |
     | |              | |
     |_|______________|_|
''',11)
a.block(69,24,r'''
       .-----------.
     .'   _______   `.
    /   .'       `.   \
   /   /    /      \   \
  |   |    /        |   |
  |   |   /         |   |
  |   |  /          |   |
   \   \           /   /
    \   `.______.'    /
     `.             .'
       `-----------'
''',7)
for x,y,s in [(39,30,'/'),(36,32,'/'),(33,34,'/'),(30,36,'/'),(60,30,'\\'),(63,32,'\\'),(66,34,'\\'),(69,36,'\\')]:a.text(x,y,s,3)
a.text(23,39,'__________/________________________\\_____________',8)
finish(a,6,'empty_tomb')
# 7: a small shepherd and a towering heavily armored opponent.
a=scene()
a.block(68,10,r'''
       __________
      /__________\
      |  _    _  |
      | | |__| | |
      | |______| |
       \________/
    ____/======\____
   /   /||||||||\   \
  /___/ |||||||| \___\
  |   | |||||||| |   |
  |   | |||||||| |   |
  |___| |||||||| |___|
   | |  ||||||||  | |
   | |  ||||||||  | |
   |_|  /======\  |_|
       /||||||||\
      /_||||||||_\
        |  ||  |
        |  ||  |
        |  ||  |
        |  ||  |
        |  ||  |
        |__||__|
       /___||___\
''',7)
a.block(18,28,r'''
       ____                  .-.
      /____\              .-'   )
      ( __ )          _.-'   _.-'
    __/|  |\_________/.----'
   /   |  |       __/
  /   /|  |______/
 /___/ |  |
       |  |
      /|  |\
     /_|__|_\
       /  \
      /    \
     /_    _\
''',15)
a.text(29,31,'|',11)
a.block(66,27,' .-------.\n |  ___  |\n | |   | |\n | |___| |\n |       |\n  \\     /\n   \\___/',8)
a.text(42,40,'__________________',8);a.text(73,40,'____________________',8)
finish(a,7,'david_and_goliath')
# 8: peaceful central robe and two unmistakable maned reclining lions.
a=scene()
for y in range(10,20):
 d=(y-10)//2;a.text(55-d,y,'/',3);a.text(57+d,y,'\\',3)
a.block(46,19,r'''
         ____
        /____\
        ( -- )
         \__/
       __/  \__
      /  |  |  \
     /   |  |   \
    /    |  |    \
   /_____|__|_____\
      |  |  |  |
      |  |  |  |
      |  |  |  |
     /   |  |   \
    /____|__|____\
''',15)
lion=r'''
     .-========-.
   .' / .----. \ `.
  / / /      \ \ \
 | | | o    o | | |
 | | |   /\   | | |
 | |  \  \/  /  | |
  \ \  '----'  / /
   `-\________/-'_________
      /    /             `-.__
     /____/    _____          `.
    /    /____/     \           \
   /____/____/       \___________)
'''
a.block(10,27,lion,3)
for j,l in enumerate(lion.strip('\n').splitlines()):a.text(112-10-len(l),27+j,l[::-1].translate(tr),3)
a.text(18,30,'o    o',11);a.text(88,30,'o    o',11)
a.text(34,42,'______________________________',8)
finish(a,8,'daniel_among_lions')
# 9: collapsing battlements; trumpeters rather than generic soldiers.
a=scene()
a.block(10,12,r'''
  __    __    __    __                   __    __    __    __
 |  |__|  |__|  |__|  |                |  |__|  |__|  |__|  |
 |____________________|                |____________________|
 |___|____|____|____|__|       /\       |__|____|____|____|___|
 |_____|____|____|_____|      /__\      |_____|____|____|_____|
 |___|____|____|____|__|   __           |__|____|____|____|___|
 |_____|____|____|_____|  /_/\      __  |_____|____|____|_____|
 |___|____|____|____|__|  \_\/     /_/  |__|____|____|____|___|
 |_____|____|____|____/\          /\    |_____|____|____|_____|
 |___|____|____|____/___\        /__\   |__|____|____|____|___|
 |_____|____|____|_/     \             |_____|____|____|_____|
 |___|____|____|_/__     /\     __     |__|____|____|____|___|
 |_____|____|__/___/    /__\   /_/\    |_____|____|____|_____|
 |___|____|_/     /\           \_\/    |__|____|____|____|___|
 |_____|__/     /__\     ____         \_____|____|____|_____|
''',8)
for x,y in [(15,32),(42,34),(72,32)]:
 a.block(x,y,r'''
    ___
   /___\       __
   ( o )======<  \
   /|  |\      \__\
  / |  | \
 /__|  |__\
    |  |
   /|  |\
  /_|__|_\
    /  \
''',15)
 a.text(x+9,y+2,'======<',11)
a.text(24,44,'___________/_____________________/_____________',3)
finish(a,9,'walls_of_jericho')
# 10: gold tongues of fire around a living branched bush.
a=scene()
a.block(57,13,r'''
              /\
             /  \
       /\   /    \    /\
      /  \ /      \  /  \
     /    V   /\  / /    \
    /  /\    /  \/ /  /\  \
   /  /  \  /     /  /  \  \
  /  /    \/  /\ /  /    \  \
 /  /   /\   /  V  /  /\  \  \
/__/___/  \_/_____/__/  \__\__\
''',9)
a.block(59,18,r'''
        /\       /\
   /\  /  \     /  \
  /  \/    \ /\/    \
 /   /  /\  V  \ /\  \
/___/__/  \_____/  \__\
''',11)
a.block(63,19,r'''
   \    |    /
    \   |   /
     \  |  /
  ____\ | /____
       \|/
   _____|_____
        |
        |
        |
       /|\
      / | \
''',2)
a.block(23,24,r'''
       ____
      /____\
      ( __ )
       \__/
    ___/  \__
   /   |  |  \___
  /    |  |      \
 /_____|  |_______\
       |  |
       |  |
      /|  |\
     / |  | \
    /__|__|__\
''',15)
a.text(19,40,'__________                 __________/_________',8)
finish(a,10,'burning_bush')
# 11: rolled waves frame a wooden occupied boat, open calm horizon.
a=scene()
wave=r'''
          __..---..__
      _.-'  .----.  `-.
    .'    .'      `.   \
   /     /   __    \   |
  /     |   /  \    |  /
 |      |   \__/   /  /
 |       \       .'  /
 |        `-----'  .'
 |              .-'
 |         __.-'
  \______-'                 __
'''
a.block(4,13,wave,6)
for j,l in enumerate(wave.strip('\n').splitlines()):a.text(112-4-len(l),13+j,l[::-1].translate(tr),6)
a.text(40,20,'_______________________________',14)
a.text(48,18,'__        __',11)
a.block(28,24,r'''
                          |
                          |\
                          | \
                          |  \
                          |   \
                          |____\
                          |
             o      o     |    o
            /|\    /|\    |   /|\
      ______/ \____/ \_____|___/ \_______
      \________________________________/
       \__|____|____|____|____|____|___/
        \____________________________/
''',3)
a.text(54,25,'|\\',15);a.text(54,26,'| \\',15);a.text(54,27,'|  \\',15);a.text(54,28,'|   \\',15);a.text(54,29,'|____\\',15)
a.text(33,39,'~~~~~    ~~~~~~~~~     ~~~~~~~~~',6);a.text(22,42,'~~~~~~~           ~~~~~~~~~~          ~~~~~~~',14)
finish(a,11,'storm_stilled')
# 12: a broken sword divides an old ruined city from restored gardens.
a=scene()
a.block(8,16,r'''
   __        __
  |  |__    |  |       __
  |     |   |  |      |  |
  |  /\ |   |  |__    |  |__
  | /  \|   |     |   |     |
  | |  ||   | /\  |   |  /\ |
  | |  ||   |/  \ |   | /  \|
  | |__||   ||  | |   | |  ||
  |_____|   ||__|_|   | |__||
 /___/      |_____|   |_____|
     __         __
    /_/\       /_/   __
    \_\/            /_/\
''',1)
a.block(53,13,r'''
  .-.
  |+|
  |=|
__|=|__
___+___
  |:|
  |:|
  |:|
  |:|
  |:|
  |:|
  |:/
  |/

   /|
  /:|
  |:|
  |:|
  |:|
  |:|
  |:|
  \:/
   V
''',15)
a.text(52,16,'___|=|___',11);a.text(51,17,'<____+____>',11)
a.block(68,18,r'''
       /\               /\
      /__\             /__\
     /____\           /____\
    | [] []|         | [] []|
    |  __  |         |  __  |
    |_|__|_|         |_|__|_|
''',11)
a.block(65,28,r'''
    _      _       _       _
   (_)    (_)     (_)     (_)
    |      |       |       |
  \ | /  \ | /   \ | /   \ | /
   \|/    \|/     \|/     \|/
____|______|_______|_______|____
''',2)
a.text(10,38,'____/___/_______',8);a.text(26,41,'___/___',1);a.text(65,38,'__       __        __',10)
finish(a,12,'hinnom_to_berachah')
# 13: lamb across the shepherd's shoulders, a luminous arch over a dark valley.
a=scene()
a.block(29,11,r'''
                    __..------..__
               _.-''              ``-._
            .-'                        `-.
          .'                              `.
         /                                  \
        /                                    \
''',3)
a.block(38,19,r'''
               ____
              /____\
              ( -- )
       .------/____\------.
      (  ___           __  )__
       \(   \_________/  \___o)
        || /  |  |   \ ||
        ||/   |  |    \||
        /|    |  |     |\
       / |    |  |     | \
      /__|____|__|_____|__\
             /|  |\
            / |  | \
           /  |  |  \
          /___|__|___\
             /    \
            /      \
''',15)
a.block(69,18,'  .--.\n  |  |\n  |  |\n     |\n     |\n     |\n     |\n     |\n     |\n     |\n     |\n     |\n     |\n     |\n     |\n     |\n     |',3)
a.block(3,29,r'''
      /\
     /  \      /\
    /    \____/  \
   /              \____
  /                    \____
 /                          \____
/                                \____
''',8)
a.block(78,29,r'''
                       /\
              /\      /  \
             /  \____/    \
        ____/              \
   ____/                    \
__/                          \
                              \
''',8)
a.text(36,40,'_________/________\\_________',3)
finish(a,13,'good_shepherd')
# 14: masonry taper, parapet and lantern-bearing watchman against darkness.
a=scene()
a.block(38,19,r'''
 __    __    __    __    __
|  |__|  |__|  |__|  |__|  |
|__________________________|
 \________________________/
  |__|____|____|____|____|_|
  |____|____|____|____|___|
  |__|____|____|____|____|_|
  |____|____|____|____|___|
  |__|____|____|____|____|_|
  |____|____|____|____|___|
  |__|____|____|____|____|_|
  |____|____|____|____|___|
  |__|____|____|____|____|_|
  |____|____|____|____|___|
  |__|____|____|____|____|_|
  |____|____|____|____|___|
  |__|____|____|____|____|_|
  |____|____|____|____|___|
  |__|____|____|____|____|_|
  |____|____|____|____|___|
  |__|____|____|____|____|_|
 /________________________\
/__________________________\
''',7)
a.block(48,11,r'''
      ___
     /___\
     ( - )
     /| |\____
    / | |     \
   /__|_|__\   |
      / \
     /___\
''',15)
a.block(62,15,'.-.\n|*|\n`-\'',11)
a.text(69,15,'--',3);a.text(70,13,'/',3);a.text(70,18,'\\',3)
a.block(48,28,'  .----.\n  |    |\n  |    |\n  |____|',8)
a.text(22,43,'__________/__________________________\\__________',8)
a.text(23,12,'.',7);a.text(84,10,'+',7);a.text(91,26,'.',7)
finish(a,14,'watchmans_tower')
# Validate actual ASCII planes, make contact sheet, and package every deliverable.
labels=['Sword beneath title','Shattered Gate','Armor of God','Michael victorious','Narrow Way - refined','Empty Tomb','David and Goliath','Daniel among Lions','Walls of Jericho','Burning Bush','Storm Stilled','Hinnom becomes Berachah','Good Shepherd','Watchman\'s Tower']
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf',23)
thumbw,thumbh=704,632
sheet=Image.new('RGB',(4*thumbw,4*(thumbh+45)), '#101014');d=ImageDraw.Draw(sheet)
for i,stem in enumerate(NAMES):
 txt=(OUT/(stem+'.txt')).read_text();assert txt.isascii();assert len(txt.splitlines())==H
 assert all(all(32<=ord(ch)<=126 for ch in line) and len(line)<=W for line in txt.splitlines())
 im=Image.open(OUT/(stem+'.png'));assert im.size==(1408,1264)
 x=(i%4)*thumbw;y=(i//4)*(thumbh+45)
 sheet.paste(im.resize((thumbw,thumbh),Image.Resampling.LANCZOS),(x,y+45))
 d.text((x+16,y+10),f'{i+1:02d} {labels[i]}',font=font,fill='#eeeeee')
sheet.save(OUT/'contact_sheet.png')
(OUT/'README.txt').write_text('RIGHTEOUSHACK - colored ASCII concept collection\n\n14 original art-only concepts. No game source changes.\nEach scene: 112 columns x 48 rows; PNG 1408 x 1264 pixels.\nANS files use the standard 16 ANSI colors on black.\nTXT files contain plain printable ASCII plus newlines.\nRender with: python3 render_collection.py (requires Pillow).\nRenderer reads three earlier v2 ANSI assets; copies included under sources/.\n\n'+'\n'.join(f'{n+1:02d}. {labels[n]}: {stem}.png / .ans / .txt' for n,stem in enumerate(NAMES))+'\n\ncontact_sheet.png: 4-column collection overview.\nnarrow_way.png: standalone copy of 05_narrow_way.png.\n')
# Bundle source dependencies for the reused compositions.
(OUT/'sources').mkdir(exist_ok=True)
for name in ('shattered_gate','armor_of_god','narrow_way'):
 pass # source dependencies already bundled
# Make the renderer portable: load the included source originals on reruns.
p=OUT/'render_collection.py';s=p.read_text().replace("(OUT/'sources'/(name+'.ans'))","(OUT/'sources'/(name+'.ans'))")
s=s.replace("OUT=Path(__file__).resolve().parent","OUT=Path(__file__).resolve().parent")
# Source-copy stage is no longer needed once archive is portable.
s=s.replace("pass # source dependencies already bundled","pass # source dependencies already bundled")
p.write_text(s)
with zipfile.ZipFile(OUT/'righteoushack_all_concepts.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(OUT.rglob('*')):
  if p.is_file() and p.suffix!='.zip':z.write(p,p.relative_to(OUT))
print('\n'.join(NAMES));print('Validated 14 ASCII grids, 14 PNG dimensions, contact sheet and ZIP.')
